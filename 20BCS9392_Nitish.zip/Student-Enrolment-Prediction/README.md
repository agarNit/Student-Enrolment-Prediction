# Student-Enrolment-Prediction-Website
A website that predicts the probability whether a student will dropout or graduate from a college given some paramters.

# Instructions to run the project :
1) Copy the structure of the project, add the model.pkl file as well as make an index.html file for teh frontend and put it inside the template folder.
2) After completing the necessary steps, like installing all required libraries and the requirements are satisfied, first run the model.py file using the command 'python <filename>', then run the command 'python app.py' to run the project locally.
3) Go to http://localhost:5000 to view the project.